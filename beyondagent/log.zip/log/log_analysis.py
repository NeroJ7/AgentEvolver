from parse_output_messages import extract_extreme_rewards_from_jsonl, parse_output_messages


agent_record_path = "45.jsonl"
human_comment_path = "human_feedback.txt"

def parsing_result(record):
    input_prompt = record.get('input', '')
    score = record.get('score', 0.0)
    interactive_message_list = parse_output_messages(record.get('output', ''))
    return input_prompt, score, interactive_message_list


LLM_generation_prompt = """
角色与任务

你是一个使用GRPO进行训练的专家。训练已稳定，希望能出一点更难的题，但如何更好提升能力。你的目标是：仅从训练数据构造角度，基于给定的最佳/最差样例和领域专家建议，分析差异并提出可执行的数据改进方案。
输入

在训练集中，Agent Interactive Message List 里涵盖了环境交互的过程，环境主要通过user字段返回。你不能考虑环境的交互情况，仅考虑agent的能力，即assistant 影响。

##################
效果最好的情况
Agent Input: {highest_input}
Agent Interactive Message List: {highest_message_list}
Final Score (Reward): {highest_score}

####################
效果最差的情况
Agent Input: {lowest_input}
Agent Interactive Message List: {lowest_message_list}
Final Score (Reward): {lowest_score}

##########
分析与输出要求

仅讨论训练数据构造相关内容（如：样本分布与覆盖、难度分层、对抗/难例构造、偏好对与负例设计、奖励标注与可分辨性、标注指南与一致性、格式与模板、清洗与去重、多轮与工具轨迹、长度与约束控制、领域多样性与术语规范等）。
禁止提出与模型结构/算法/超参/解码/推理时策略/评测流程相关的建议。
明确对比“最佳 vs 最差”的差异：输入难度与歧义、约束复杂度、领域知识需求、上下文长度、格式要求、工具调用需求；输出中的错误类型：不遵循指令、事实/逻辑错误、步骤遗漏、格式不合规、冗长/过短、风格偏差等。
建议需简洁、可执行、面向数据落地。给出最重要的至多3条建议，不需要强行找到3条，建议每条不超过一行。
如信息不足以提出数据层面的改进，直接输出：无需改进。
建议的问题请仔细参考后续提供的案例，尽可能改良并提出更合理的样本

###################
请注意，只需要从训练集的问题的构造角度提出建议，避免泛泛而谈，避免谈论奖励构造，后续交互过程的评价，避免对环境过程的改变等，例如禁止考虑改变环境的交互情况、不需要考虑轨迹生成的情况、不需要考虑改变各类模板或者工具返回结果。
请注意，你只可以从Query构造角度提出修改，修改最原始的问题。请不要考虑Agent本身构造，并且相信优化算法会从更简单或更难的问题中学习并改善相关能力。
你需要考虑的是如何更好的设计问题，让agent主动去完成交互。例如，将多个工具或者问题的组合优化，或者单个问题的删减取材，或者单个问题的不同维度的重构等。在构造时，可以思考参考环境可能的反馈情况，不能胡编乱造。
如果当前的指标完成较好，需要提升难度，可以增加单个query内问题的个数或者一个query内多个问题的组合情况；如果当前任务完全情况不够好，需要降低难度，可以减少单个query内问题的个数，或减少逻辑复杂度。

我们需要提供的训练样本均为模型生成，因此需要更合理的生成建议。提供了需要迭代前的2个训练样本为：
"query":"Find a grey mid-century accent chair with metal legs under $230 that explicitly states 'easy assembly' and 'easy clean' in its description","ground_truth":"# step0\nsearch[mid century easy clean easy assemble accent chairs metal legs living room dining room gray under 230]\n# step1\nclick[grey] (after viewing product details)\n# step2\nclick[features]\n# step3\nclick[description]",

"query":"Find the cheapest dark blonde hair extension under $50 with a size of at least 8 inches","ground_truth":"# step0\nsearch[dark blonde hair extensions size>=8 inch under $50]\n# step1\nscroll through results and click items\n# step2\ncheck item details for price and size\n# step3\ncompare prices of valid options"

# 反思
输出前请反思一下，最后输出的query是否满足改进的建议。
如果有领域专家建议，请总结理解，并加入后续的改进建议中
 {user_experience}
#################

输出格式（严格遵守）

分析原因:

要点1
要点2
要点3

改进建议:
建议1
建议2
建议3

上一轮已经较好的问题：
Agent Input:

请避免下述Query的构造，例如：

建议生成的问题：
Query1:
Query2:



"""


en_prompt="""

Role & Task

You are an expert in training using GRPO. Training has stabilized, and you want to generate more difficult questions, but also look for ways to further improve capabilities. Your goal is: solely from the perspective of training data construction, based on the provided best/worst examples and domain expert suggestions, analyze the differences and propose actionable data improvement plans.

Input

In the training set, the Agent Interactive Message List covers the process of environment interaction, and the environment mainly responds through the user field. You must not consider environmental interaction, only focus on the agent’s capabilities, i.e., the assistant’s influence.

##################
Best-performing case
Agent Input: {highest_input}
Agent Interactive Message List: {highest_message_list}
Final Score (Reward): {highest_score}

####################
Worst-performing case
Agent Input: {lowest_input}
Agent Interactive Message List: {lowest_message_list}
Final Score (Reward): {lowest_score}

##########
Analysis & Output Requirements

Discuss only issues related to training data construction (e.g., sample distribution and coverage, difficulty stratification, adversarial/hard example construction, preference and negative example design, reward annotation and distinguishability, annotation guidelines and consistency, format and template, data cleaning and deduplication, multi-turn and tool trajectory, length and constraint control, domain diversity, terminology standardization, etc.).

Suggestions related to model architecture/algorithm/hyperparameters/decoding/inference strategy/evaluation process are strictly prohibited.
Explicitly compare "best vs. worst" differences: input difficulty and ambiguity, constraint complexity, domain knowledge requirements, context length, format requirements, tool invocation needs; error types in output: not following instructions, factual/logical errors, step omissions, format violations, verbosity/terse responses, style deviations, etc.
Suggestions must be concise, actionable, and practical for data implementation. Give a maximum of 3 top suggestions (don’t force 3 if not needed), and keep each suggestion under one line.
If there is insufficient information to propose data-level improvements, simply respond: No improvements needed.
When generating suggestions, please closely reference the examples provided afterwards and improve or propose more reasonable samples as much as possible.

###################
Note: Only provide suggestions from the perspective of question (query) construction in the training set—avoid being generic, avoid discussing reward construction, subsequent interaction evaluation, or changes to environment processes. For example, do not consider changing the environment interaction, generating trajectories, or altering templates/tool return results.
Note: You may only propose modifications from the perspective of Query construction—modifying the original question. Do not consider Agent construction, and trust that the optimization algorithm will learn and improve from both easier and harder problems.
You need to focus on how to better design the questions to prompt the agent towards proactive interaction. For example, optimizing combinations of multiple tools or questions, reducing material in a single question, or reconstructing a single question from different dimensions, etc. You can consider referencing possible environment feedback during construction, but do not fabricate it.
If the metrics are already good, to increase difficulty, you can add more sub-questions in a single query or combine multiple issues in one query; if performance is insufficient, decrease difficulty by reducing the number of sub-questions or lowering logical complexity.

All training samples we provide are model-generated, so we need more reasonable generation suggestions. The following are 2 training samples before iteration:
"query":"Find a grey mid-century accent chair with metal legs under $230 that explicitly states 'easy assembly' and 'easy clean' in its description","ground_truth":"# step0\nsearch[mid century easy clean easy assemble accent chairs metal legs living room dining room gray under 230]\n# step1\nclick[grey] (after viewing product details)\n# step2\nclick[features]\n# step3\nclick[description]",

"query":"Find the cheapest dark blonde hair extension under 50 with a size of at least 8 inches","ground_truth":"# step0\nsearch[dark blonde hair extensions size>=8 inch under 50]\n# step1\nscroll through results and click items\n# step2\ncheck item details for price and size\n# step3\ncompare prices of valid options"

Reflection
Before outputting, reflect whether the final output query meets the suggestions for improvement.
If there are any domain expert suggestions, summarize and incorporate them into the subsequent improvement suggestions.
{user_experience}
#################

Output Format (STRICTLY FOLLOW)

Analysis of the reasons:

Point 1
Point 2
Point 3

Improvement Suggestions:
Suggestion 1
Suggestion 2
Suggestion 3

Already well-constructed queries from the previous round:
Agent Input:

Avoid constructing queries like the following:

Improved sample queries:
Query1:
Query2:
"""

def load_human_comments(file_path):
    """Load human comments from file"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return f.read().strip()
    except FileNotFoundError:
        return "没有提供人类反馈"
    except Exception as e:
        return f"读取人类反馈时出错: {str(e)}"

def generate_agent_result_review(human_comments_path=None):
    highest_reward_record, lowest_reward_record = extract_extreme_rewards_from_jsonl(agent_record_path)

    # Parse the records
    highest_input, highest_score, highest_interactive_message_list = parsing_result(highest_reward_record)
    lowest_input, lowest_score, lowest_interactive_message_list = parsing_result(lowest_reward_record)

    # Load human comments
    if human_comments_path is None:
        human_comments_path = human_comment_path
    human_comments = load_human_comments(human_comments_path)
    
    # Format the message lists for better readability
    highest_message_str = "\n".join([f"{msg['role']}: {msg['content']}" for msg in highest_interactive_message_list])
    lowest_message_str = "\n".join([f"{msg['role']}: {msg['content']}" for msg in lowest_interactive_message_list])
    
    # Fill the prompt template
    filled_prompt = LLM_generation_prompt.format(
        highest_input=highest_input,
        highest_message_list=highest_message_str,
        highest_score=highest_score,
        lowest_input=lowest_input,
        lowest_message_list=lowest_message_str,
        lowest_score=lowest_score,
        user_experience=human_comments
    )

    en_prompts = en_prompt.format(
        highest_input=highest_input,
        highest_message_list=highest_message_str,
        highest_score=highest_score,
        lowest_input=lowest_input,
        lowest_message_list=lowest_message_str,
        lowest_score=lowest_score,
        user_experience=human_comments
    )
    
    return filled_prompt,en_prompts

if __name__ == "__main__":
    # Generate and print the filled prompt
    filled_prompt,en_prompts = generate_agent_result_review()
    print(filled_prompt)

    from openai import OpenAI
    import os

    sse_client = OpenAI(
        api_key=os.getenv("ANTHROPIC_AUTH_TOKEN"),
        base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",
    )
    model_name = "qwen-max"  # Always use GPT-4o regardless of input model_name

    response = sse_client.chat.completions.create(
        model=model_name,
        messages={"role": "user", "content": filled_prompt},
        # messages=[
        #     {"role": "system", "content": system_msgs},
        #     {"role": "user", "content": user_msgs},
        # ],
    )

    final_comments =response.choices[0].message.content