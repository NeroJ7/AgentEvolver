import json
import re

def extract_extreme_rewards_from_jsonl(file_path):
    """Extract records with highest and lowest rewards from 45.jsonl"""
    try:
        records = []
        
        # Read file line by line as each line is a separate JSON object
        with open(file_path, 'r') as f:
            for line in f:
                line = line.strip()
                if line:  # Skip empty lines
                    try:
                        record = json.loads(line)
                        records.append(record)
                    except json.JSONDecodeError:
                        print(f"Warning: Skipping invalid JSON line: {line}")
        
        if len(records) > 0:
            # Filter out records with null rewards for comparison
            valid_records = [r for r in records if r.get('reward') is not None]
            
            if len(valid_records) > 0:
                # Find record with maximum reward
                max_reward_record = max(valid_records, key=lambda x: x.get('reward', float('-inf')))
                # Find record with minimum reward
                min_reward_record = min(valid_records, key=lambda x: x.get('reward', float('inf')))
                
                return max_reward_record, min_reward_record
            else:
                print("No records with valid rewards found")
                return None, None
        else:
            print("No data found in the file")
            return None, None
            
    except FileNotFoundError:
        print(f"File {file_path} not found")
        return None, None
    except Exception as e:
        print(f"Error processing file: {e}")
        return None, None

def parse_output_messages(output_text):
    """Parse the output text into a list of messages with roles"""
    messages = []
    
    # The first message is always from assistant (not explicitly marked)
    # Split by user\n or assistant\n to separate messages
    parts = re.split(r'(user\n|assistant\n)', output_text)
    
    # Remove empty parts
    parts = [part for part in parts if part.strip()]
    
    role = "assistant"  # First message is always from assistant
    content = ""
    
    for i, part in enumerate(parts):
        if part == "user\n":
            # Save previous message
            if content.strip():
                messages.append({
                    "role": role,
                    "content": content.strip()
                })
            # Set role to user for next message
            role = "user"
            content = ""
        elif part == "assistant\n":
            # Save previous message
            if content.strip():
                messages.append({
                    "role": role,
                    "content": content.strip()
                })
            # Set role to assistant for next message
            role = "assistant"
            content = ""
        else:
            # This is content
            content += part
    
    # Don't forget the last message
    if content.strip():
        messages.append({
            "role": role,
            "content": content.strip()
        })
    
    return messages

def print_message_list(messages):
    """Print the message list in a readable format"""
    for i, msg in enumerate(messages):
        print(f"Message {i+1} ({msg['role']}):")
        print(msg['content'])
        print("-" * 50)

# Extract and store the records in variables
highest_reward_record, lowest_reward_record = extract_extreme_rewards_from_jsonl("45.jsonl")




if __name__ == "__main__":
    # Parse and display messages for highest reward record
    if highest_reward_record:
        print("=== HIGHEST REWARD RECORD (Reward: 1.0) ===")
        print()
        output_text = highest_reward_record.get('output', '')
        messages = parse_output_messages(output_text)
        print(f"Found {len(messages)} messages in output:")
        print()
        print_message_list(messages)
        print()
    
    # Parse and display messages for lowest reward record
    if lowest_reward_record:
        print("=== LOWEST REWARD RECORD (Reward: 0.0) ===")
        print()
        output_text = lowest_reward_record.get('output', '')
        messages = parse_output_messages(output_text)
        print(f"Found {len(messages)} messages in output:")
        print()
        print_message_list(messages)
        print()